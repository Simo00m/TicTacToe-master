package com.example.tictactoe

fun checkWinner(cellStates: Map<Int, String>): Pair<String?, List<Int>?> {
    //data for all possible winning combos
    val winningCombos = listOf(
        listOf(1, 2, 3),
        listOf(4, 5, 6),
        listOf(7, 8, 9),
        listOf(1, 4, 7),
        listOf(2, 5, 8),
        listOf(3, 6, 9),
        listOf(1, 5, 9),
        listOf(3, 5, 7)
    )

    for (combo in winningCombos) {
        //default here for no errors

        val first: String = cellStates[combo[0]] ?: ""
        if (first != "" && combo.all { cellStates[it] == first }) {
            return Pair(first, combo)
        }
    }
    //return not
    return Pair(null, null)
}

fun checkDraw(cellStates: Map<Int, String>): Boolean {
    return cellStates.count { it.value != "" } == 9
}
