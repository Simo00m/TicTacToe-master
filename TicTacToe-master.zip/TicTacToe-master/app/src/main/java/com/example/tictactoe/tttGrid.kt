package com.example.tictactoe

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color.Companion.Black
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay
import kotlin.collections.set

@Composable
fun tttGrid() {
    var cellStates = remember { mutableStateMapOf<Int, String>().apply { cellIds.forEach { this[it] = "" } } }
    //state for remembering player turn
    var playerState = remember { "x" }
    //winner state
    var winnerState = remember { mutableStateOf<String?>(null)}
    //winning path for animations on winning
    var winningPath by remember { mutableStateOf<List<Int>?>(null) }

    val resetGame = {
        cellStates.keys.forEach { cellStates[it] = "" }
        playerState = "x"
        winnerState.value = null
    }

    //winning animation
    if(winnerState.value != null && winnerState.value != "draw"){
        LaunchedEffect(winnerState.value){
            cellIds.forEach { id ->
                delay(100)
                cellStates[id] = winnerState.value!!
            }
        }
    }

    //box to house winner label and grid
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center){
        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            modifier = Modifier
                .fillMaxSize()
                .background(Black),
            verticalArrangement = Arrangement.Center,
            contentPadding = PaddingValues(20.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            items(cellIds) { cellId ->
                Box(
                    modifier = Modifier
                        .aspectRatio(1f)
                        .fillMaxSize()
                        .padding(4.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(White),
                    contentAlignment = Alignment.Center
                ) {
                    xoCards(
                        cellId = cellId,
                        cellState = cellStates[cellId] ?: ""
                    ) { clickedId ->
                        if (cellStates[clickedId] == "") {
                            cellStates[clickedId] = playerState

                            val (winner, winnerCombo) = checkWinner(cellStates)

                            if (winner != null) {
                                winnerState.value = winner
                                winningPath = winnerCombo
                            }else if(checkDraw(cellStates)){
                                winnerState.value = "draw"
                            }else{
                                playerState = if (playerState == "x") "o" else "x"
                            }
                        }
                    }
                }
            }
        }

    }
//if there is a winner overlay the winner and reset button
    if (winnerState.value != null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(White.copy(alpha = 0.19f), RoundedCornerShape(10.dp))
                .zIndex(0f),
            contentAlignment = Alignment.Center
        ){
            winningScreen(resetButton = resetGame, winner = winnerState.value.toString())
        }
    }

}
