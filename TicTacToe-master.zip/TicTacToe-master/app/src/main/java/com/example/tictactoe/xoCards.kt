package com.example.tictactoe

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Color.Companion.White
import androidx.compose.ui.text.font.FontWeight.Companion.Bold
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex


@Composable
fun xoCards(cellId: Int, cellState: String, onCardClick: (Int) -> Unit) {
    val pieceColor = when (cellState) {
        "x" -> Color.Red
        "o" -> Color.Blue
        else -> White
    }
    Card(
        modifier = Modifier
            .size(100.dp)
            .zIndex(1f),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(10.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(pieceColor)
                .clickable { if (cellState == "") onCardClick(cellId) },
            contentAlignment = Alignment.Center
        ) {
            Text(text = cellState, color = White, fontWeight = Bold, fontSize = 30.sp)

        }
    }
}
