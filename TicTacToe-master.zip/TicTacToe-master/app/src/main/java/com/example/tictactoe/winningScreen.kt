package com.example.tictactoe

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment.Companion.CenterHorizontally
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color.Companion.Black
import androidx.compose.ui.text.style.TextAlign.Companion.Center
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp


@Composable
fun winningScreen(winner: String, resetButton: () -> Unit) {

    Column(
        horizontalAlignment = CenterHorizontally
    ) {
        val winnerText = if (winner == "draw") "draw" else winner
//            val xShape = remember {}
        Text(
            winnerText, fontSize = 80.sp, color = Black, textAlign = Center
        )
        Spacer(modifier = Modifier.height(height = 20.dp))
        Button(onClick = resetButton) {
            Text("Reset", color = Black)
        }
    }

}

